echo ACTUALIZACIÓN DE PAQUETES

sudo apt update && sudo apt upgrade

sudo apt-get install python3

sudo apt-get install rar

pip3 install conda

wget https://raw.githubusercontent.com/circulosmeos/gdown.pl/master/gdown.pl
chmod +x gdown.pl

git clone https://github.com/FuentesFelipe/ml_clasificadorDeFrutas
cd ml_clasificadorDeFrutas

echo DESCARGANDO DATASET

perl gdown.pl https://drive.google.com/file/d/1L1wn9v_9dVeaANEpuXXGFY8zXAAA5yVr/view?usp=sharing dataset.rar

echo DESCOMPRIMIENDO DATASET

unrar x dataset.rar

conda create -n ml_env

conda activate ml_env

conda install jupyter notebook tensorflow jupyter notebook tensorflow matplotlib

jupyter notebook

